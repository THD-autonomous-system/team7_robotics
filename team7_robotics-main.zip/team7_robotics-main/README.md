# team8_prototype

jemty.jose@gmail.com

# Team Members 
# Amalu Tresa, Jacob Thomas, Jemty Jose, Joseph Linoy Arakkal, Rahul Planthottathukunnel Girijan, Rose Mathew

